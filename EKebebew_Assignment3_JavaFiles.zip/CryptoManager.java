/*
 * Class: CMSC203 21754
 * Instructor: Professor Gregoriy Grinberg
 * Description: (The first method determines if a string is within the allowable bounds of ASCII codes. 
And the second method encrypts a string using caesarEncryption method .and it returns the encrypted string.
And the third method, caesarDecryption decrypts the string.And the bellasoEncryption method encripts the string while the 
last method decrypts the string.)
 * Due: 10/10/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: _Estifanos Kebebew_________
*/

package com.ekebebew;


public class CryptoManager {

		/**
		 * This class manages static methods to encrypt and decrypt  text according to Caesar and Bellaso methods.
		 * @author 
		 *
		 */
			private static final char LOWER = ' ';
			private static final char UPPER = '_';
			private static final int RANGE = UPPER - LOWER + 1;

			/**
			 * This method determines if a string is within the allowable bounds of ASCII codes 
			 * according to the LOWER_BOUND and UPPER_BOUND characters
			 * @param plainText a string to be encrypted, if it is within the allowable bounds
			 * @return true if all characters are within the allowable bounds, false if any character is outside
			 */
			public static boolean isStringInBounds (String plainText) {
				boolean boundary = true;
				for (int i = 0; i < plainText.length(); i++) {
					if (!(plainText.charAt(i) >= LOWER && plainText.charAt(i) <=UPPER)) {
						
						boundary= false;
					}
				}
				return boundary;
			}

			/**
			 * Encrypts a string according to the Caesar Cipher.  The integer key specifies an offset
			 * and each character in plainText is replaced by the character \"offset\" away from it 
			 * @param plainText an uppercase string to be encrypted.
			 * @param key an integer that specifies the offset of each character
			 * @return the encrypted string
			 */
			public static String caesarEncryption(String plainText, int key) {

				String encryptedText = "";
				
				if(isStringInBounds(plainText)==true) {
					for(int i=0; i<plainText.length(); i++) {
						char thisChar =plainText.charAt(i);
						int encryptedCharint=((int)thisChar+key);
						while(encryptedCharint>UPPER) {
							encryptedCharint-=RANGE;
						}
						encryptedText+=(char)encryptedCharint;
					}
					}
				else {
					encryptedText ="The selected string is not in bounds, Try again.";
				}
				return encryptedText;
			}
			
			/**
			 * Encrypts a string according the Bellaso Cipher.  Each character in plainText is offset 
			 * according to the ASCII value of the corresponding character in bellasoStr, which is repeated
			 * to correspond to the length of plainText
			 * @param plainText an uppercase string to be encrypted.
			 * @param bellasoStr an uppercase string that specifies the offsets, character by character.
			 * @return the encrypted string
			 */
			public static String bellasoEncryption(String plainText, String bellasoStr)
			{
				
				String encryptedText = "";
				int bellasoStrLength= bellasoStr.length();
				for(int i=0;i<plainText.length();i++) {
					char thisChar =plainText.charAt(i);
					int encryptedCharint=((int)thisChar+(int)bellasoStr.charAt(i % bellasoStrLength));
							while(encryptedCharint>(int)UPPER) {
								encryptedCharint-=RANGE;
							}
							encryptedText +=(char)encryptedCharint;
				}
				return encryptedText;
			}
				
				
			/**
			 * Decrypts a string according to the Caesar Cipher.  The integer key specifies an offset
			 * and each character in encryptedText is replaced by the character \"offset\" characters before it.
			 * This is the inverse of the encryptCaesar method.
			 * @param encryptedText an encrypted string to be decrypted.
			 * @param key an integer that specifies the offset of each character
			 * @return the plain text string
			 */
			public static String caesarDecryption(String encryptedText, int key) {
				String decryptedText = "";
				for(int i=0;i<encryptedText.length();i++) {
					char thisChar=encryptedText.charAt(i);
					int decryptedCharint=((int)thisChar-key);
					while(decryptedCharint<LOWER) {
						decryptedCharint+=RANGE;
					}
					decryptedText+=(char)decryptedCharint;
				}
				return decryptedText;
				
			}
			
			/**
			 * Decrypts a string according the Bellaso Cipher.  Each character in encryptedText is replaced by
			 * the character corresponding to the character in bellasoStr, which is repeated
			 * to correspond to the length of plainText.  This is the inverse of the encryptBellaso method.
			 * @param encryptedText an uppercase string to be encrypted.
			 * @param bellasoStr an uppercase string that specifies the offsets, character by character.
			 * @return the decrypted string
			 */
			public static String bellasoDecryption(String encryptedText, String bellasoStr) {
				String decryptedText = "";
				int bellasoStrLength=bellasoStr.length();
				
				for(int i =0; i<encryptedText.length();i++) {
					char thisChar= encryptedText.charAt(i);
					int decryptedCharint=((int)thisChar-(int)bellasoStr.charAt(i%bellasoStrLength));
					while(decryptedCharint<(int)LOWER) {
						decryptedCharint+=RANGE;
					}
					decryptedText+=(char)decryptedCharint;
				}
				return decryptedText;
				
			}
			
	}
	

