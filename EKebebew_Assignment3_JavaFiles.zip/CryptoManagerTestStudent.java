/*
 * Class: CMSC203 21754
 * Instructor: Professor Gregoriy Grinberg
 * Description: (The first method determines if a string is within the allowable bounds of ASCII codes. 
And the second method encrypts a string using caesarEncryption method .and it returns the encrypted string.
And the third method, caesarDecryption decrypts the string.And the bellasoEncryption method encripts the string while the 
last method decrypts the string.)
 * Due: 10/10/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: _Estifanos Kebebew_________
*/

package com.ekebebew;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CryptoManagerTestStudent {
	
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testStringInBounds() {
		assertTrue(CryptoManager.isStringInBounds("THIS TEST SHOULD SUCCEED"));
		assertFalse(CryptoManager.isStringInBounds("TEST SHOULD FAIL BECAUSE ~ IS OUTSIDE THE RANGE"));
		assertFalse(CryptoManager.isStringInBounds("This test should fail because of lowercase letters"));
	}

	@Test
	public void testCaesarEncryption() {
		assertEquals("]QR\\)]N\\])\\QX^UM)YJ\\\\",CryptoManager.caesarEncryption("THIS TEST SHOULD PASS", 9));
		assertEquals("^RS]*^O]^*S]*KXY^RO\\", CryptoManager.caesarEncryption("THIS TEST IS ANOTHER", 10));
		assertEquals("\"_&&):1),&^", CryptoManager.caesarEncryption("HELLO WORLD", 90));
	}
	
	@Test
	public void testCaesarDecryption() {
		assertEquals("THIRD TEST", CryptoManager.caesarDecryption("WKLUG#WHVW", 3));
		
	}

	@Test
	public void testBellasoEncryption() {
		assertEquals("$M,FV:_]+", CryptoManager.bellasoEncryption("TEST FOUR", "PHY264"));
		assertEquals("XI)BOTXI%>EKUM'", CryptoManager.bellasoEncryption("HAPPY HALLOWEEN", "PHY264"));
		assertEquals("KPTU\\/LFO[S\\HTR", CryptoManager.bellasoEncryption("HAPPY HALLOWEEN", "CODE")); 
		                                                                                      
	}

	@Test
	public void testbellasoDecryption() {
		assertEquals("THIS IS ANOTHER TEST", CryptoManager.bellasoDecryption("WU\\VR9F#N!RF88U-'HED", "CMSC203"));
		assertEquals("HAPPY HALLOWEEN", CryptoManager.bellasoDecryption("XI)BOTXI%>EKUM'", "PHY264"));
		assertEquals("HAPPY HALLOWEEN", CryptoManager.bellasoDecryption("KPTU\\/LFO[S\\HTR","CODE")); 

	}

}